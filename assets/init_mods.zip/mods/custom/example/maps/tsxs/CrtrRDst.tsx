<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="CrtrRDst" tilewidth="20" tileheight="20" tilecount="24" columns="8">
 <image source="../tiles/CrtrRDst.png" trans="008a76" width="160" height="60"/>
</tileset>
