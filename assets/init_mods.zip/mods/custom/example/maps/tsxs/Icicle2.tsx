<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Icicle2" tilewidth="20" tileheight="20" tilecount="2" columns="1">
 <image source="../tiles/Icicle2.png" trans="ff00ff" width="20" height="40"/>
 <tile id="0">
  <properties>
   <property name="small-icicle" value=""/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="small-icicle" value=""/>
  </properties>
 </tile>
</tileset>
