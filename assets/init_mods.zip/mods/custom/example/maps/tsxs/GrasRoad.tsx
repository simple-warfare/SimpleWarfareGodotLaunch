<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="GrasRoad" tilewidth="20" tileheight="20" tilecount="117" columns="13">
 <image source="../tiles/GrasRoad.png" trans="008a76" width="260" height="180"/>
</tileset>
