<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="MntMisc" tilewidth="20" tileheight="20" tilecount="48" columns="8">
 <image source="../tiles/MntMisc.png" trans="008a76" width="160" height="120"/>
</tileset>
