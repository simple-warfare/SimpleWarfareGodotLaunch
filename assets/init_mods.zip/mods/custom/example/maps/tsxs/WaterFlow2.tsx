<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="WaterFlow2" tilewidth="20" tileheight="20" tilecount="7" columns="7">
 <image source="../tiles/WaterFlow2.png" trans="008a76" width="140" height="20"/>
 <tile id="0" type="water">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="20" height="20"/>
  </objectgroup>
  <animation>
   <frame tileid="0" duration="300"/>
   <frame tileid="1" duration="300"/>
   <frame tileid="2" duration="300"/>
   <frame tileid="3" duration="300"/>
   <frame tileid="4" duration="300"/>
   <frame tileid="5" duration="300"/>
   <frame tileid="6" duration="300"/>
  </animation>
 </tile>
</tileset>
