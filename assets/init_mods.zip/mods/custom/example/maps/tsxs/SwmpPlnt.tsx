<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="SwmpPlnt" tilewidth="20" tileheight="20" tilecount="1" columns="1">
 <image source="../tiles/SwmpPlnt.png" trans="008a76" width="20" height="20"/>
</tileset>
