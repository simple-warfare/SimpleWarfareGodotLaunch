<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="LavaBubl" tilewidth="20" tileheight="20" tilecount="60" columns="15">
 <image source="../tiles/LavaBubl.png" trans="008a76" width="300" height="80"/>
</tileset>
