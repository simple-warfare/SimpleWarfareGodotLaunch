<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="SnwCratr" tilewidth="20" tileheight="20" tilecount="5" columns="5">
 <image source="../tiles/SnwCratr.png" trans="008a76" width="100" height="20"/>
</tileset>
