<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="SwmpRDst" tilewidth="20" tileheight="20" tilecount="21" columns="3">
 <image source="../tiles/SwmpRDst.png" trans="008a76" width="60" height="140"/>
</tileset>
