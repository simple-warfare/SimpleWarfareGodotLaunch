<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="StnRock1" tilewidth="20" tileheight="20" tilecount="2" columns="1">
 <image source="../tiles/StnRock1.png" trans="008a76" width="20" height="40"/>
</tileset>
