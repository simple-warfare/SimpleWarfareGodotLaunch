<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Snw2-Rck2" tilewidth="20" tileheight="20" tilecount="1" columns="1">
 <image source="../tiles/Snw2-Rck2.png" trans="209070" width="20" height="20"/>
</tileset>
