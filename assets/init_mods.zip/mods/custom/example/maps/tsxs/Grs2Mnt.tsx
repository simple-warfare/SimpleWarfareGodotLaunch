<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Grs2Mnt" tilewidth="20" tileheight="20" tilecount="45" columns="5">
 <image source="../tiles/Grs2Mnt.png" trans="008a76" width="100" height="180"/>
</tileset>
