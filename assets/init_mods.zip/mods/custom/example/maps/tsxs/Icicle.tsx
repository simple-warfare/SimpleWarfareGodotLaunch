<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Icicle" tilewidth="20" tileheight="20" tilecount="6" columns="2">
 <image source="../tiles/Icicle.png" trans="ff00ff" width="40" height="60"/>
</tileset>
