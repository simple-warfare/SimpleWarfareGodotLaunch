import { Turret } from "std:custom/turret.mjs";
import * as manyFromValues from "std:from-values.mjs";
import { TargetType } from "std:simple-warfare-cli/target.mjs";
import { ComfirmDialog } from "std:ui/quick/dialog/comfirm.mjs";
export class SingleTurret extends Turret {
  constructor() {
    super(
      manyFromValues.transfrom(
        manyFromValues.vec3(0, 0, 1),
        undefined,
        undefined
      ),
      manyFromValues.graphic(
        53,
        26,
        "single_turret.png",
        undefined,
        undefined,
        undefined,
        undefined,
        manyFromValues.vec2(-10, 0)
      ),
      666,
      true,
      200
    );

    this.created_func = () => {
      simpleWarfareCli.lookAt(
        TargetType.Position,
        this.entity,
        manyFromValues.vec2(
          Math.floor(Math.random() * (300 + 1)),
          Math.floor(Math.random() * (300 + 1))
        )
      );
    };
    this.onUnitEnterFunc = (units) => {
      simpleWarfareCli.lookAt(TargetType.Entity, this.entity, units[0]);
      this.quick_dialog = new ComfirmDialog("Damage", "Damage Hp 10");
      this.target_entity = units[0];
      this.quick_dialog.onPressComfirm.connect(this.onPressComfirmFunc);
    };

    this.onPressComfirmFunc = () => {
      let target_proxy = simpleWarfareCli.getProxy(this.target_entity);

      console.log(`before:${target_proxy.core.hp}`);
      target_proxy.getCore().hp -= 100;
      console.log(`after:${target_proxy.core.hp}`);
    };

    this.onUnitExitFunc = (units) => {};
    this.onUnitEnter.connect(this.onUnitEnterFunc);
    this.onUnitExit.connect(this.onUnitExitFunc);
    this.created.connect(this.created_func);
    this.created.emit();
  }
}
