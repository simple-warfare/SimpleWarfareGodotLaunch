export class Entity {
  constructor(index, generation) {
    this.index = index;
    this.generation = generation;
  }
}
