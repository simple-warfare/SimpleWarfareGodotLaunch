export const QuickDialogType = {
    Comfirm: "Comfirm",
};