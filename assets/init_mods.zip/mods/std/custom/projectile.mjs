export class Projectile {
  constructor() {}
}
