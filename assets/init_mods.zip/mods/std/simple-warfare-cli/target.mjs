export const TargetType = {
    Position: 'Position',
    Entity: 'Entity'
};